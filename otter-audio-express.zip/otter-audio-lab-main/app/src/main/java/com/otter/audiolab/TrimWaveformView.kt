package com.otter.audiolab

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Menampilkan gelombang (waveform) lagu yang sedang dibuka, lengkap dengan
 * dua gagang (handle) yang bisa digeser langsung di atas gelombang untuk
 * menentukan titik awal & akhir bagian yang mau dipotong (trim), serta garis
 * "playhead" yang menunjukkan posisi putar saat ini.
 *
 * Semua koordinat waktu disimpan dalam milidetik (ms).
 */
class TrimWaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var durationMs: Long = 0L
        private set
    var trimStartMs: Long = 0L
        private set
    var trimEndMs: Long = 0L
        private set
    private var playheadMs: Long = 0L

    private var amplitudes: FloatArray = FloatArray(0)

    /** Dipanggil setiap kali gagang start/end digeser oleh pengguna. */
    var onTrimChanged: ((startMs: Long, endMs: Long) -> Unit)? = null

    /** Dipanggil saat pengguna mengetuk area gelombang (di luar gagang) untuk pindah posisi putar. */
    var onSeekRequested: ((positionMs: Long) -> Unit)? = null

    private val barPaintInactive = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4D4D4D") }
    private val barPaintActive = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#66BB6A") }
    private val dimOverlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B3000000") }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFC107") }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 4f }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E1E1E") }

    private var draggingHandle = 0 // 0 = tidak ada, 1 = start, 2 = end
    private val handleWidthPx = 10f
    private var touchSlopPx = 56f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        if (amplitudes.isEmpty() || durationMs <= 0L) {
            canvas.drawLine(0f, h / 2f, w, h / 2f, barPaintInactive)
            return
        }

        val n = amplitudes.size
        val barSlot = w / n
        val startX = (trimStartMs.toFloat() / durationMs) * w
        val endX = (trimEndMs.toFloat() / durationMs) * w

        for (i in 0 until n) {
            val x = i * barSlot
            val amp = amplitudes[i].coerceIn(0.03f, 1f)
            val barH = amp * h * 0.92f
            val top = (h - barH) / 2f
            val insideSelection = x + barSlot / 2f in startX..endX
            canvas.drawRect(x, top, x + barSlot * 0.75f, top + barH, if (insideSelection) barPaintActive else barPaintInactive)
        }

        // Gelapkan bagian di luar area terpilih supaya area trim jelas terlihat
        if (startX > 0f) canvas.drawRect(0f, 0f, startX, h, dimOverlayPaint)
        if (endX < w) canvas.drawRect(endX, 0f, w, h, dimOverlayPaint)

        // Gagang start & end
        canvas.drawRect(startX - handleWidthPx / 2f, 0f, startX + handleWidthPx / 2f, h, handlePaint)
        canvas.drawRect(endX - handleWidthPx / 2f, 0f, endX + handleWidthPx / 2f, h, handlePaint)

        // Playhead
        val playX = (playheadMs.toFloat() / durationMs) * w
        canvas.drawLine(playX, 0f, playX, h, playheadPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (durationMs <= 0L || width == 0) return false
        val w = width.toFloat()
        val startX = (trimStartMs.toFloat() / durationMs) * w
        val endX = (trimEndMs.toFloat() / durationMs) * w

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                draggingHandle = when {
                    abs(event.x - startX) <= touchSlopPx -> 1
                    abs(event.x - endX) <= touchSlopPx -> 2
                    else -> {
                        val ms = ((event.x / w) * durationMs).toLong().coerceIn(0L, durationMs)
                        onSeekRequested?.invoke(ms)
                        0
                    }
                }
                parent.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (draggingHandle != 0) {
                    val ms = ((event.x / w) * durationMs).toLong().coerceIn(0L, durationMs)
                    if (draggingHandle == 1) {
                        trimStartMs = ms.coerceAtMost((trimEndMs - MIN_GAP_MS).coerceAtLeast(0L))
                    } else {
                        trimEndMs = ms.coerceAtLeast((trimStartMs + MIN_GAP_MS).coerceAtMost(durationMs))
                    }
                    invalidate()
                    onTrimChanged?.invoke(trimStartMs, trimEndMs)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                draggingHandle = 0
                parent.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    /** Set data gelombang baru (dipanggil setelah file lagu dianalisis). */
    fun setWaveform(amps: FloatArray, totalDurationMs: Long) {
        amplitudes = amps
        durationMs = totalDurationMs
        trimStartMs = 0L
        trimEndMs = totalDurationMs
        playheadMs = 0L
        invalidate()
    }

    /** Update posisi awal/akhir trim dari luar (misalnya dari kotak input angka). */
    fun setTrimRange(startMs: Long, endMs: Long) {
        if (durationMs <= 0L) return
        trimStartMs = startMs.coerceIn(0L, durationMs)
        trimEndMs = endMs.coerceIn(trimStartMs, durationMs)
        invalidate()
    }

    fun setPlayheadMs(ms: Long) {
        playheadMs = ms.coerceIn(0L, if (durationMs > 0L) durationMs else 0L)
        invalidate()
    }

    companion object {
        private const val MIN_GAP_MS = 200L
    }
}
