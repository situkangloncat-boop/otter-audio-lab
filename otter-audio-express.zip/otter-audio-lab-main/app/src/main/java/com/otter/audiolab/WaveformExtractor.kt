package com.otter.audiolab

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Mendekode file audio jadi array amplitudo (0f..1f) yang sudah di-downsample
 * ke sejumlah "bar" tertentu, dipakai untuk menggambar waveform di
 * [TrimWaveformView]. Dijalankan di background thread karena proses decode
 * bisa memakan waktu untuk lagu yang panjang.
 */
object WaveformExtractor {

    data class Result(val amplitudes: FloatArray, val durationMs: Long)

    fun extract(path: String, barCount: Int = 260, knownDurationMs: Long = 0L): Result {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(path)
        } catch (e: Exception) {
            return Result(FloatArray(barCount), knownDurationMs)
        }

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex < 0 || format == null) {
            extractor.release()
            return Result(FloatArray(barCount), knownDurationMs)
        }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        var channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
        val durationMs = if (durationUs > 0L) durationUs / 1000L else knownDurationMs

        var estimatedTotalFrames = if (durationMs > 0L) (durationMs / 1000.0 * sampleRate).toLong() else 0L

        val codec: MediaCodec
        try {
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
        } catch (e: Exception) {
            extractor.release()
            return Result(FloatArray(barCount), durationMs)
        }

        val bufferInfo = MediaCodec.BufferInfo()
        val sums = DoubleArray(barCount)
        val counts = LongArray(barCount)
        var processedFrames = 0L
        var sawInputEOS = false
        var sawOutputEOS = false
        val timeoutUs = 10_000L

        try {
            while (!sawOutputEOS) {
                if (!sawInputEOS) {
                    val inIndex = codec.dequeueInputBuffer(timeoutUs)
                    if (inIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inIndex)
                        val sampleSize = if (inputBuffer != null) extractor.readSampleData(inputBuffer, 0) else -1
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            sawInputEOS = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outIndex)
                    if (outputBuffer != null && bufferInfo.size > 0 && channelCount > 0) {
                        outputBuffer.order(ByteOrder.LITTLE_ENDIAN)
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuffer = outputBuffer.asShortBuffer()
                        val sampleCount = shortBuffer.remaining()
                        val frameCount = sampleCount / channelCount
                        if (estimatedTotalFrames <= 0L) estimatedTotalFrames = frameCount.toLong() * 200L // fallback kasar
                        val chunk = ShortArray(sampleCount)
                        shortBuffer.get(chunk)
                        for (f in 0 until frameCount) {
                            var sum = 0
                            for (c in 0 until channelCount) {
                                sum += abs(chunk[f * channelCount + c].toInt())
                            }
                            val avg = sum.toDouble() / channelCount
                            val bucket = if (estimatedTotalFrames > 0L)
                                ((processedFrames.toDouble() / estimatedTotalFrames) * barCount).toInt().coerceIn(0, barCount - 1)
                            else 0
                            sums[bucket] += avg
                            counts[bucket] += 1L
                            processedFrames++
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) sawOutputEOS = true
                } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = codec.outputFormat
                    channelCount = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT, channelCount)
                    sampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE, sampleRate)
                }
            }
        } catch (e: Exception) {
            // Kalau decode gagal di tengah jalan, tetap pakai data yang sudah terkumpul.
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            extractor.release()
        }

        val amplitudes = FloatArray(barCount)
        var maxVal = 0.0001
        for (i in 0 until barCount) {
            val avg = if (counts[i] > 0L) sums[i] / counts[i] else 0.0
            amplitudes[i] = avg.toFloat()
            if (avg > maxVal) maxVal = avg
        }
        for (i in 0 until barCount) amplitudes[i] = (amplitudes[i] / maxVal).toFloat().coerceIn(0f, 1f)

        val finalDurationMs = if (durationMs > 0L) durationMs else (processedFrames * 1000L / sampleRate.coerceAtLeast(1))
        return Result(amplitudes, finalDurationMs)
    }
}
